define(['utils'], function (Utils) {
	'use strict';
  
	var labels = {
    //"transcript": (Utils.lang === "en")?	
    //    "Transcript" :
    //    "TBD"
  };
	
  return labels;
});